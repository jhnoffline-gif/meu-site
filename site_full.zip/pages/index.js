export default function Home() {
  return <h1>IAForce - Site Completo Restaurado</h1>;
}
